package Day08.Ex06_Multi_Implement;


// 검색 기능을 갖는 디바이스에 대한 인터페이스
public interface Searchable {
	
	// 검색 기능
	void search(String url);

}
