package Day08.Ex07_InterfaceExtends;

public interface InterfaceC extends InterfaceA, InterfaceB {

	public void methodC();
}
